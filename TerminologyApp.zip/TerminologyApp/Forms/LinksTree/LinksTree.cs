﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using TerminologyApp.Models;

namespace TerminologyApp.Forms
{
    public partial class LinksTree : Form
    {
        private Term _startTerm;
        private List<Term> _allTerms;

        public LinksTree(Term startTerm, List<Term> allTerms)
        {
            InitializeComponent();
            this.KeyPreview = true;
            this.KeyDown += LinksTree_KeyDown;

            _startTerm = startTerm;
            _allTerms = allTerms;
            label1.Text = $"Ланцюжок визначень для: {startTerm.Name}";
            label1.Location = new Point((this.ClientSize.Width - label1.Width) / 2, label1.Location.Y);
            BuildTree();
            tvChain.NodeMouseDoubleClick += TvChain_NodeMouseDoubleClick;
        }

        private void LinksTree_KeyDown(object? sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }

        private Term GetTermById(Guid id)
        {
            for (int i = 0; i < _allTerms.Count; i++)
            {
                if (_allTerms[i].Id == id)
                    return _allTerms[i];
            }
            return null;
        }

        private void BuildTree()
        {
            tvChain.Nodes.Clear();
            if (_startTerm == null) return;

            TreeNode rootNode = CreateNode(_startTerm);
            tvChain.Nodes.Add(rootNode);
            AddChildren(_startTerm, rootNode, new HashSet<Guid>());
            tvChain.ExpandAll();
        }

        private TreeNode CreateNode(Term term)
        {
            TreeNode node = new TreeNode($"{term.Name}");
            node.Tag = term;
            node.ToolTipText = term.Definition;
            return node;
        }

        private void AddChildren(Term parent, TreeNode parentNode, HashSet<Guid> pathIds)
        {
            if (parent.LinkedTermIds == null) return;

            for (int i = 0; i < parent.LinkedTermIds.Count; i++)
            {
                Guid linkedId = parent.LinkedTermIds[i];
                Term child = GetTermById(linkedId);
                if (child == null) continue;

                if (pathIds.Contains(child.Id))
                {
                    MessageBox.Show($"Виявлено циклічне посилання на термін \"{child.Name}\". Побудова ланцюжка для цього напрямку зупинена.",
                                    "Циклічне посилання", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    continue;
                }

                TreeNode childNode = CreateNode(child);
                parentNode.Nodes.Add(childNode);

                pathIds.Add(parent.Id);
                AddChildren(child, childNode, pathIds);
                pathIds.Remove(parent.Id);
            }
        }

        private void TvChain_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.Tag is Term term)
            {
                MessageBox.Show($"Термін: {term.Name}\n\nВизначення:\n{term.Definition}", "Визначення", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
