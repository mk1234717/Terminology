﻿namespace TerminologyApp.Forms
{
    partial class LinksTree
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tvChain = new TreeView();
            label1 = new Label();
            SuspendLayout();
            // 
            // tvChain
            // 
            tvChain.HideSelection = false;
            tvChain.Location = new Point(76, 69);
            tvChain.Name = "tvChain";
            tvChain.ShowNodeToolTips = true;
            tvChain.Size = new Size(496, 229);
            tvChain.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label1.Location = new Point(153, 9);
            label1.Name = "label1";
            label1.Size = new Size(319, 25);
            label1.TabIndex = 1;
            label1.Text = "Ланцюжок визначень для терміна";
            // 
            // LinksTree
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(650, 343);
            Controls.Add(label1);
            Controls.Add(tvChain);
            Name = "LinksTree";
            Text = "LinksTree";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TreeView tvChain;
        private Label label1;
    }
}