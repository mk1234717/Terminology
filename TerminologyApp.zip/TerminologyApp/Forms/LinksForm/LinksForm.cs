﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Windows.Forms;
using TerminologyApp.Models;

namespace TerminologyApp.Forms
{
    public partial class LinksForm : Form
    {
        private List<Term> links;
        public Term CreatedTerm = new Term();
        List<Guid> prevTermIds = new List<Guid>();
        public LinksForm(Term term, List<Term> links, List<Term> termLinks)
        {
            InitializeComponent();
            this.KeyPreview = true;
            this.KeyDown += LinksForm_KeyDown;

            this.links = links;
            label1.Text = $"Посилання для терміна: {term.Name}";
            label1.Location = new Point((this.ClientSize.Width - label1.Width) / 2, label1.Location.Y);

            for (int i = 0; i < links.Count; i++)
            {
                lbAvailableDates.Items.Add(links[i]);
            }

            for (int i = 0; i < term.LinkedTermIds.Count; i++)
            {
                lbLinksFromTheCurrent.Items.Add(termLinks[i]);
            }

            lbAvailableDates.DisplayMember = "Name";
            lbLinksFromTheCurrent.DisplayMember = "Name";

            List<Guid> thisTermIds = new List<Guid>();
            foreach (var linkedId in term.LinkedTermIds)
            {
                prevTermIds.Add(linkedId);
                thisTermIds.Add(linkedId);
            }
            CreatedTerm.LinkedTermIds = thisTermIds;
            CreatedTerm.Id = term.Id;
        }

        private void LinksForm_KeyDown(object? sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                btnCancel.PerformClick();
            }
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            if (lbAvailableDates.SelectedItem == null) return;
            Term termToRight = (Term)lbAvailableDates.SelectedItem;
            lbAvailableDates.Items.Remove(termToRight);
            lbLinksFromTheCurrent.Items.Add(termToRight);
            CreatedTerm.LinkedTermIds.Add(termToRight.Id);
        }

        private void btnL_Click(object sender, EventArgs e)
        {
            if (lbLinksFromTheCurrent.SelectedItem == null) return;
            Term termToLeft = (Term)lbLinksFromTheCurrent.SelectedItem;
            lbLinksFromTheCurrent.Items.Remove(termToLeft);

            lbAvailableDates.Items.Add(termToLeft);
            CreatedTerm.LinkedTermIds.Remove(termToLeft.Id);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            bool changesMade = false;

            if (CreatedTerm.LinkedTermIds.Count != prevTermIds.Count)
            {
                changesMade = true;
            }
            else
            {
                for (int i = 0; i < CreatedTerm.LinkedTermIds.Count; i++)
                {
                    if (!prevTermIds.Contains(CreatedTerm.LinkedTermIds[i]))
                    {
                        changesMade = true;
                        break;
                    }
                }
            }

            if (changesMade)
            {
                if (MessageBox.Show("Ви впевнені, що хочете скасувати зміни?", "Підтвердження", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
            }
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
