﻿namespace TerminologyApp.Forms
{
    partial class LinksForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lbAvailableDates = new ListBox();
            label2 = new Label();
            lbLinksFromTheCurrent = new ListBox();
            label3 = new Label();
            btnR = new Button();
            btnL = new Button();
            btnOk = new Button();
            btnCancel = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label1.Location = new Point(239, 9);
            label1.Name = "label1";
            label1.Size = new Size(188, 25);
            label1.TabIndex = 0;
            label1.Text = "Зв'язки для терміна";
            // 
            // lbAvailableDates
            // 
            lbAvailableDates.FormattingEnabled = true;
            lbAvailableDates.HorizontalScrollbar = true;
            lbAvailableDates.Location = new Point(41, 91);
            lbAvailableDates.Name = "lbAvailableDates";
            lbAvailableDates.Size = new Size(212, 169);
            lbAvailableDates.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F);
            label2.Location = new Point(41, 57);
            label2.Name = "label2";
            label2.Size = new Size(133, 20);
            label2.TabIndex = 2;
            label2.Text = "Доступні терміни:";
            // 
            // lbLinksFromTheCurrent
            // 
            lbLinksFromTheCurrent.FormattingEnabled = true;
            lbLinksFromTheCurrent.HorizontalScrollbar = true;
            lbLinksFromTheCurrent.Location = new Point(404, 91);
            lbLinksFromTheCurrent.Name = "lbLinksFromTheCurrent";
            lbLinksFromTheCurrent.Size = new Size(212, 169);
            lbLinksFromTheCurrent.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(404, 57);
            label3.Name = "label3";
            label3.Size = new Size(179, 20);
            label3.TabIndex = 4;
            label3.Text = "Посилання з поточного:";
            // 
            // btnR
            // 
            btnR.BackColor = Color.LightGray;
            btnR.FlatAppearance.BorderColor = Color.Black;
            btnR.FlatStyle = FlatStyle.Popup;
            btnR.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            btnR.Location = new Point(311, 131);
            btnR.Name = "btnR";
            btnR.Size = new Size(40, 35);
            btnR.TabIndex = 5;
            btnR.Text = ">";
            btnR.UseVisualStyleBackColor = false;
            btnR.Click += btnR_Click;
            // 
            // btnL
            // 
            btnL.BackColor = Color.LightGray;
            btnL.FlatAppearance.BorderColor = Color.Black;
            btnL.FlatStyle = FlatStyle.Popup;
            btnL.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            btnL.Location = new Point(311, 172);
            btnL.Name = "btnL";
            btnL.Size = new Size(40, 35);
            btnL.TabIndex = 7;
            btnL.Text = "<";
            btnL.UseVisualStyleBackColor = false;
            btnL.Click += btnL_Click;
            // 
            // btnOk
            // 
            btnOk.Location = new Point(12, 281);
            btnOk.Name = "btnOk";
            btnOk.Size = new Size(75, 23);
            btnOk.TabIndex = 8;
            btnOk.Text = "OK";
            btnOk.UseVisualStyleBackColor = true;
            btnOk.Click += btnOk_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(93, 281);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 9;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // LinksForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(651, 325);
            Controls.Add(btnCancel);
            Controls.Add(btnOk);
            Controls.Add(btnL);
            Controls.Add(btnR);
            Controls.Add(label3);
            Controls.Add(lbLinksFromTheCurrent);
            Controls.Add(label2);
            Controls.Add(lbAvailableDates);
            Controls.Add(label1);
            Name = "LinksForm";
            Text = "LinksForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private ListBox lbAvailableDates;
        private Label label2;
        private ListBox lbLinksFromTheCurrent;
        private Label label3;
        private Button btnR;
        private Button btnL;
        private Button btnOk;
        private Button btnCancel;
    }
}