﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Reflection.Emit;
using System.Security.Policy;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using TerminologyApp.Models;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TerminologyApp.Forms.MainForm
{
    public partial class AddEditTermForm : Form
    {
        private Image _defaultImage;
        private Term _editingTerm;

        public AddEditTermForm(List<string> existingCategories, int mode, Term term = null)
        {
            InitializeComponent();
            this.KeyPreview = true;
            this.KeyDown += AddEditTermForm_KeyDown;

            _defaultImage = pbPreview.Image;
            _editingTerm = term;

            cmbCategory.Items.Clear();
            cmbCategory.Items.Add("Загальна");
            for (int i = 0; i < existingCategories.Count; i++)
            {
                if (existingCategories[i] != "Загальна")
                    cmbCategory.Items.Add(existingCategories[i]);
            }

            if (mode == 1)
            {
                cmbCategory.SelectedIndex = 0;
                cmbStatus.SelectedIndex = 0;
                pbPreview.Image = _defaultImage;
            }
            else if (mode == 2 && term != null)
            {
                label1.Text = "Редагування терміна";

                tbName.Text = term.Name;
                tbDefinition.Text = term.Definition;
                tbLink.Text = term.ImagePath;

                int catIndex = cmbCategory.Items.IndexOf(term.Category);
                cmbCategory.SelectedIndex = catIndex >= 0 ? catIndex : 0;

                int statusIndex = cmbStatus.Items.IndexOf(term.Status);
                cmbStatus.SelectedIndex = statusIndex >= 0 ? statusIndex : 0;

                LoadImageFromPath(term.ImagePath);
            }
            else if (mode == 3 && term != null)
            {
                label1.Text = "Перегляд терміна";

                tbName.Text = term.Name;
                tbDefinition.Text = term.Definition;
                tbLink.Text = term.ImagePath;

                int catIndex = cmbCategory.Items.IndexOf(term.Category);
                cmbCategory.SelectedIndex = catIndex >= 0 ? catIndex : 0;

                int statusIndex = cmbStatus.Items.IndexOf(term.Status);
                cmbStatus.SelectedIndex = statusIndex >= 0 ? statusIndex : 0;

                LoadImageFromPath(term.ImagePath);

                tbName.ReadOnly = true;
                tbName.BackColor = SystemColors.Window;
                tbDefinition.ReadOnly = true;
                tbDefinition.BackColor = SystemColors.Window;
                tbLink.ReadOnly = true;
                tbLink.BackColor = SystemColors.Window;
                cmbCategory.Hide();
                label4.Text = $"Категорія: {term.Category}";
                cmbStatus.Hide();
                label5.Text = $"Статус: {term.Status}";
                btnOK.Hide();
                btnChoose.Hide();
                btnCancel.Hide();
                if (term.ImagePath == "")
                {
                    tbLink.Hide();
                    label6.Hide();
                    pbPreview.Hide();
                    this.Height = 329;
                }
            }
        }

        private void AddEditTermForm_KeyDown(object? sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                if (btnCancel.Visible)
                    btnCancel.PerformClick();
                else
                {
                    this.Close();
                }
            }
        }

        private void btnChoose_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Title = "Виберіть зображення";
                openFileDialog.Filter = "Зображення|*.png;*.jpg;*.jpeg|PNG (*.png)|*.png|JPEG (*.jpg;*.jpeg)|*.jpg;*.jpeg";
                openFileDialog.FilterIndex = 1;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    tbLink.Text = openFileDialog.FileName;

                    try
                    {
                        pbPreview.Image = Image.FromFile(openFileDialog.FileName);
                        pbPreview.SizeMode = PictureBoxSizeMode.Zoom;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Не вдалося завантажити зображення: " + ex.Message);
                    }
                }
            }
        }

        private void LoadImageFromPath(string path)
        {
            if (path == "")
            {
                pbPreview.Image = _defaultImage;
                pbPreview.SizeMode = PictureBoxSizeMode.CenterImage;
                return;
            }
            try
            {
                pbPreview.Image = Image.FromFile(path);
                pbPreview.SizeMode = PictureBoxSizeMode.Zoom;
            }
            catch
            {
                pbPreview.Image = _defaultImage;
                pbPreview.SizeMode = PictureBoxSizeMode.CenterImage;
                MessageBox.Show("Не вдалося завантажити зображення. Перевірте шлях до файлу.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void tbLink_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                e.Handled = true;
                LoadImageFromPath(tbLink.Text);
            }
        }
        private void tbLink_Leave(object sender, EventArgs e)
        {
            LoadImageFromPath(tbLink.Text);
        }

        public Term CreatedTerm { get; private set; }
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbName.Text))
            {
                MessageBox.Show("Назва терміна не може бути порожньою.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (string.IsNullOrWhiteSpace(tbDefinition.Text))
            {
                MessageBox.Show("Визначення не може бути порожнім.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (string.IsNullOrWhiteSpace(cmbCategory.Text))
            {
                MessageBox.Show("Категорія не може бути порожньою.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if(pbPreview.Image == _defaultImage && tbLink.Text != "")
            {
                MessageBox.Show("Не вдалося завантажити зображення. Перевірте шлях до файлу.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (_editingTerm == null)
            {
                CreatedTerm = new Term(tbName.Text, tbDefinition.Text, cmbCategory.Text, cmbStatus.Text, tbLink.Text);
            }
            else
            {
                Term newTerm = new Term(tbName.Text, tbDefinition.Text, cmbCategory.Text, cmbStatus.Text, tbLink.Text);
                newTerm.Id = _editingTerm.Id;
                newTerm.LinkedTermIds = new List<Guid>(_editingTerm.LinkedTermIds);
                CreatedTerm = newTerm;
            }

            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}