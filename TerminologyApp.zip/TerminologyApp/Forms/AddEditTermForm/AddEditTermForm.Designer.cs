﻿using TerminologyApp.Models;

namespace TerminologyApp.Forms.MainForm
{
    partial class AddEditTermForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        public AddEditTermForm()
        {
            InitializeComponent();
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddEditTermForm));
            label1 = new Label();
            label2 = new Label();
            tbName = new TextBox();
            label3 = new Label();
            tbDefinition = new TextBox();
            label4 = new Label();
            cmbCategory = new ComboBox();
            label5 = new Label();
            cmbStatus = new ComboBox();
            label6 = new Label();
            tbLink = new TextBox();
            btnChoose = new Button();
            pbPreview = new PictureBox();
            btnOK = new Button();
            btnCancel = new Button();
            ((System.ComponentModel.ISupportInitialize)pbPreview).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label1.Location = new Point(241, 9);
            label1.Name = "label1";
            label1.Size = new Size(184, 25);
            label1.TabIndex = 0;
            label1.Text = "Додавання терміна";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 57);
            label2.Name = "label2";
            label2.Size = new Size(88, 15);
            label2.TabIndex = 1;
            label2.Text = "Назва терміна:";
            // 
            // tbName
            // 
            tbName.Location = new Point(106, 54);
            tbName.MaxLength = 100;
            tbName.Name = "tbName";
            tbName.Size = new Size(266, 23);
            tbName.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 91);
            label3.Name = "label3";
            label3.Size = new Size(75, 15);
            label3.TabIndex = 3;
            label3.Text = "Визначення:";
            // 
            // tbDefinition
            // 
            tbDefinition.Location = new Point(93, 88);
            tbDefinition.Multiline = true;
            tbDefinition.Name = "tbDefinition";
            tbDefinition.ScrollBars = ScrollBars.Vertical;
            tbDefinition.Size = new Size(380, 128);
            tbDefinition.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 231);
            label4.Name = "label4";
            label4.Size = new Size(62, 15);
            label4.TabIndex = 5;
            label4.Text = "Категорія:";
            // 
            // cmbCategory
            // 
            cmbCategory.FormattingEnabled = true;
            cmbCategory.Items.AddRange(new object[] { "Загальна" });
            cmbCategory.Location = new Point(80, 228);
            cmbCategory.Name = "cmbCategory";
            cmbCategory.Size = new Size(147, 23);
            cmbCategory.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 264);
            label5.Name = "label5";
            label5.Size = new Size(46, 15);
            label5.TabIndex = 7;
            label5.Text = "Статус:";
            // 
            // cmbStatus
            // 
            cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbStatus.FormattingEnabled = true;
            cmbStatus.Items.AddRange(new object[] { "проєктний", "затверджений", "застарілий" });
            cmbStatus.Location = new Point(80, 261);
            cmbStatus.Name = "cmbStatus";
            cmbStatus.Size = new Size(147, 23);
            cmbStatus.TabIndex = 8;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(12, 308);
            label6.Name = "label6";
            label6.Size = new Size(79, 15);
            label6.TabIndex = 9;
            label6.Text = "Зображення:";
            // 
            // tbLink
            // 
            tbLink.Location = new Point(97, 305);
            tbLink.Name = "tbLink";
            tbLink.Size = new Size(215, 23);
            tbLink.TabIndex = 10;
            tbLink.KeyPress += tbLink_KeyPress;
            tbLink.Leave += tbLink_Leave;
            // 
            // btnChoose
            // 
            btnChoose.Location = new Point(318, 304);
            btnChoose.Name = "btnChoose";
            btnChoose.Size = new Size(75, 23);
            btnChoose.TabIndex = 11;
            btnChoose.Text = "Обрати...";
            btnChoose.UseVisualStyleBackColor = true;
            btnChoose.Click += btnChoose_Click;
            // 
            // pbPreview
            // 
            pbPreview.Image = (Image)resources.GetObject("pbPreview.Image");
            pbPreview.Location = new Point(399, 228);
            pbPreview.Name = "pbPreview";
            pbPreview.Size = new Size(242, 175);
            pbPreview.SizeMode = PictureBoxSizeMode.CenterImage;
            pbPreview.TabIndex = 12;
            pbPreview.TabStop = false;
            // 
            // btnOK
            // 
            btnOK.Location = new Point(12, 380);
            btnOK.Name = "btnOK";
            btnOK.Size = new Size(75, 23);
            btnOK.TabIndex = 13;
            btnOK.Text = "OK";
            btnOK.UseVisualStyleBackColor = true;
            btnOK.Click += btnOK_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(93, 380);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 14;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // AddEditTermForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(653, 415);
            Controls.Add(btnCancel);
            Controls.Add(btnOK);
            Controls.Add(pbPreview);
            Controls.Add(btnChoose);
            Controls.Add(tbLink);
            Controls.Add(label6);
            Controls.Add(cmbStatus);
            Controls.Add(label5);
            Controls.Add(cmbCategory);
            Controls.Add(label4);
            Controls.Add(tbDefinition);
            Controls.Add(label3);
            Controls.Add(tbName);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "AddEditTermForm";
            Text = "AddEditTermForm";
            ((System.ComponentModel.ISupportInitialize)pbPreview).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox tbName;
        private Label label3;
        private TextBox tbDefinition;
        private Label label4;
        private ComboBox cmbCategory;
        private Label label5;
        private ComboBox cmbStatus;
        private Label label6;
        private TextBox tbLink;
        private Button btnChoose;
        private PictureBox pbPreview;
        private Button btnOK;
        private Button btnCancel;
    }
}