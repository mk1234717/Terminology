﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using TerminologyApp.Forms.MainForm;
using TerminologyApp.Models;

namespace TerminologyApp
{
    public partial class MainForm : Form
    {
        private TermManager _termManager = new TermManager();

        public MainForm()
        {
            InitializeComponent();

            cmbCategorySearch.SelectedIndex = 0;
            cmbStatusSearch.SelectedIndex = 0;
        }

        private void ExitTSMI_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AboutTSMI_Click(object sender, EventArgs e)
        {
            string message =
        "Термінологія\n" +
        "Версія 1.0\n\n" +
        "Програма призначена для створення та ведення бази визначень термінів певної науки або предметної області.\n\n" +
        "Основні можливості:\n" +
        "• Додавання, редагування, видалення термінів\n" +
        "• Встановлення зв'язків між поняттями\n" +
        "• Перегляд ланцюжка визначень до первинних понять\n" +
        "• Пошук за назвою, категорією, статусом, текстом визначення\n" +
        "• Збереження та завантаження бази у JSON";

            MessageBox.Show(message, "Про програму", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtNameSearch.Clear();
            txtDefinitionSearch.Clear();
            cmbCategorySearch.SelectedIndex = 0;
            cmbStatusSearch.SelectedIndex = 0;
        }

        private void RefreshForm(string name, string category, string status)
        {
            if (!cmbCategorySearch.Items.Contains(category))
            {
                cmbCategorySearch.Items.Add(category);
            }

            dGVTerms.Rows.Add(name, category, status);
        }

        private void butAdd_Click(object sender, EventArgs e)
        {
            List<string> categories = new List<string>();
            for (int i = 1; i < cmbCategorySearch.Items.Count; i++)
            {
                categories.Add(cmbCategorySearch.Items[i].ToString());
            }

            AddEditTermForm addForm = new AddEditTermForm(categories, 1);
            if (addForm.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    _termManager.AddTerm(addForm.CreatedTerm);
                    RefreshForm(addForm.CreatedTerm.Name, addForm.CreatedTerm.Category, addForm.CreatedTerm.Status);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dGVTerms.CurrentRow == null)
            {
                MessageBox.Show("Оберіть термін для видалення.");
                return;
            }

            string termName = dGVTerms.CurrentRow.Cells["colName"].Value.ToString();
            DialogResult confirm = MessageBox.Show($"Видалити термін '{termName}'?", "Підтвердження", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm != DialogResult.Yes)
                return;

            Term termToDelete = null;
            for (int i = 0; i < _termManager.Terms.Count; i++)
            {
                if (_termManager.Terms[i].Name == termName)
                {
                    termToDelete = _termManager.Terms[i];
                    break;
                }
            }

            if (termToDelete == null)
            {
                MessageBox.Show("Термін не знайдено в базі.");
                return;
            }

            try
            {
                _termManager.DeleteTerm(termToDelete.Id, force: false);
                bool currentCategoryStillExists = false;
                for (int i = 0; i < _termManager.Terms.Count; i++)
                {
                    if (_termManager.Terms[i].Category == dGVTerms.CurrentRow.Cells["colCategory"].Value.ToString())
                    {
                        currentCategoryStillExists = true;
                        break;
                    }
                }
                if (!currentCategoryStillExists)
                {
                    cmbCategorySearch.Items.Remove(dGVTerms.CurrentRow.Cells["colCategory"].Value.ToString());
                }
                dGVTerms.Rows.RemoveAt(dGVTerms.CurrentRow.Index);
            }
            catch (InvalidOperationException ex)
            {
                if (ex.Message.Contains("посилаються"))
                {
                    DialogResult forceConfirm = MessageBox.Show(
                        "На цей термін посилаються інші. Видалити разом із посиланнями?",
                        "Попередження",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Warning);
                    if (forceConfirm == DialogResult.Yes)
                    {
                        _termManager.DeleteTerm(termToDelete.Id, force: true);
                        bool currentCategoryStillExists = false;
                        for (int i = 0; i < _termManager.Terms.Count; i++)
                        {
                            if (_termManager.Terms[i].Category == dGVTerms.CurrentRow.Cells["colCategory"].Value.ToString())
                            {
                                currentCategoryStillExists = true;
                                break;
                            }
                        }
                        if (!currentCategoryStillExists)
                        {
                            cmbCategorySearch.Items.Remove(dGVTerms.CurrentRow.Cells["colCategory"].Value.ToString());
                        }
                        dGVTerms.Rows.RemoveAt(dGVTerms.CurrentRow.Index);
                    }
                }
                else
                {
                    MessageBox.Show(ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dGVTerms.CurrentRow == null)
            {
                MessageBox.Show("Оберіть термін для редагування.");
                return;
            }

            List<string> categories = new List<string>();
            for (int i = 1; i < cmbCategorySearch.Items.Count; i++)
            {
                categories.Add(cmbCategorySearch.Items[i].ToString());
            }

            string termName = dGVTerms.CurrentRow.Cells["colName"].Value.ToString();
            Term termToEdit = null;
            for (int i = 0; i < _termManager.Terms.Count; i++)
            {
                if (_termManager.Terms[i].Name == termName)
                {
                    termToEdit = _termManager.Terms[i];
                    break;
                }
            }
            if (termToEdit == null)
            {
                MessageBox.Show("Термін не знайдено.");
                return;
            }

            string currentCategory = termToEdit.Category;
            AddEditTermForm editForm = new AddEditTermForm(categories, 2, termToEdit);
            if (editForm.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    _termManager.UpdateTerm(editForm.CreatedTerm, 1);
                    int rowIndex = dGVTerms.CurrentRow.Index;
                    dGVTerms.Rows[rowIndex].Cells["colName"].Value = editForm.CreatedTerm.Name;
                    dGVTerms.Rows[rowIndex].Cells["colCategory"].Value = editForm.CreatedTerm.Category;
                    dGVTerms.Rows[rowIndex].Cells["colStatus"].Value = editForm.CreatedTerm.Status;
                    if (currentCategory != editForm.CreatedTerm.Category)
                    {
                        bool currentCategoryStillExists = false;
                        for (int i = 0; i < _termManager.Terms.Count; i++)
                        {
                            if (_termManager.Terms[i].Category == currentCategory)
                            {
                                currentCategoryStillExists = true;
                                break;
                            }
                        }
                        if (!currentCategoryStillExists)
                        {
                            cmbCategorySearch.Items.Remove(currentCategory);
                        }

                        string newCategory = editForm.CreatedTerm.Category;
                        if (!cmbCategorySearch.Items.Contains(newCategory))
                        {
                            cmbCategorySearch.Items.Add(newCategory);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
