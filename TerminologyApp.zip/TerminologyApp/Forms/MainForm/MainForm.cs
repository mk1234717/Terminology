﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using TerminologyApp.Forms;
using TerminologyApp.Forms.MainForm;
using TerminologyApp.Models;
using TerminologyApp.Services;

namespace TerminologyApp
{
    public partial class MainForm : Form
    {
        private TermManager _termManager = new TermManager();
        private DataStorageService _storageService = new DataStorageService();
        private string _currentFilePath = null;
        private bool _isDirty = false;

        public MainForm()
        {
            InitializeComponent();

            cmbCategorySearch.SelectedIndex = 0;
            cmbStatusSearch.SelectedIndex = 0;

            this.FormClosing += MainForm_FormClosing;
            LoadDefaultDatabase();
        }

        private void LoadDefaultDatabase()
        {
            string defaultPath = Path.Combine(Application.StartupPath, "terms.json");
            if (File.Exists(defaultPath))
            {
                var loaded = _storageService.LoadFromFile(defaultPath);
                _termManager.Terms.Clear();
                _termManager.Terms.AddRange(loaded);
                _currentFilePath = defaultPath;
                _isDirty = false;
                RefreshDisplay();
            }
        }

        private void RefreshDisplay()
        {
            dGVTerms.Rows.Clear();
            foreach (var t in _termManager.Terms)
                dGVTerms.Rows.Add(t.Name, t.Category, t.Status);

            cmbCategorySearch.Items.Clear();
            cmbCategorySearch.Items.Add("");
            foreach (var t in _termManager.Terms)
                if (!cmbCategorySearch.Items.Contains(t.Category))
                    cmbCategorySearch.Items.Add(t.Category);
            cmbCategorySearch.SelectedIndex = 0;
        }

        private void SaveToFile(string path)
        {
            _storageService.SaveToFile(_termManager.Terms, path);
            _currentFilePath = path;
            _isDirty = false;
            MessageBox.Show("Збережено", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void SaveAs()
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "JSON files (*.json)|*.json";
            sfd.DefaultExt = "json";
            if (sfd.ShowDialog() == DialogResult.OK)
                SaveToFile(sfd.FileName);
        }

        private void SaveCurrent()
        {
            if (string.IsNullOrEmpty(_currentFilePath))
                SaveAs();
            else
                SaveToFile(_currentFilePath);
        }

        private void OpenFile()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "JSON files (*.json)|*.json";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                var loaded = _storageService.LoadFromFile(ofd.FileName);
                _termManager.Terms.Clear();
                _termManager.Terms.AddRange(loaded);
                _currentFilePath = ofd.FileName;
                _isDirty = false;
                RefreshDisplay();
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_isDirty)
            {
                DialogResult res = MessageBox.Show("Зберегти зміни?", "Вихід", MessageBoxButtons.YesNoCancel);
                if (res == DialogResult.Yes)
                    SaveCurrent();
                else if (res == DialogResult.Cancel)
                    e.Cancel = true;
            }
        }

        private void ExitTSMI_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AboutTSMI_Click(object sender, EventArgs e)
        {
            string message =
        "Термінологія\n" +
        "Версія 1.0\n\n" +
        "Програма призначена для створення та ведення бази визначень термінів певної науки або предметної області.\n\n" +
        "Основні можливості:\n" +
        "• Додавання, редагування, видалення термінів\n" +
        "• Встановлення зв'язків між поняттями\n" +
        "• Перегляд ланцюжка визначень до первинних понять\n" +
        "• Пошук за назвою, категорією, статусом, текстом визначення\n" +
        "• Збереження та завантаження бази у JSON";

            MessageBox.Show(message, "Про програму", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtNameSearch.Clear();
            txtDefinitionSearch.Clear();
            cmbCategorySearch.SelectedIndex = 0;
            cmbStatusSearch.SelectedIndex = 0;

            RefreshDisplay();
        }

        private void butAdd_Click(object sender, EventArgs e)
        {
            List<string> categories = new List<string>();
            for (int i = 1; i < cmbCategorySearch.Items.Count; i++)
            {
                categories.Add(cmbCategorySearch.Items[i].ToString());
            }

            AddEditTermForm addForm = new AddEditTermForm(categories, 1);
            if (addForm.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    _termManager.AddTerm(addForm.CreatedTerm);
                    _isDirty = true;
                    RefreshDisplay();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dGVTerms.CurrentRow == null)
            {
                MessageBox.Show("Оберіть термін для видалення.");
                return;
            }

            string termName = dGVTerms.CurrentRow.Cells["colName"].Value.ToString();
            DialogResult confirm = MessageBox.Show($"Видалити термін '{termName}'?", "Підтвердження", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm != DialogResult.Yes)
                return;

            Term termToDelete = null;
            foreach (var t in _termManager.Terms)
            {
                if (t.Name == termName)
                {
                    termToDelete = t;
                    break;
                }
            }

            if (termToDelete == null)
            {
                MessageBox.Show("Термін не знайдено в базі.");
                return;
            }

            try
            {
                _termManager.DeleteTerm(termToDelete.Id, force: false);
                _isDirty = true;
                RefreshDisplay();
            }
            catch (InvalidOperationException ex)
            {
                if (ex.Message.Contains("посилаються"))
                {
                    DialogResult forceConfirm = MessageBox.Show(
                        "На цей термін посилаються інші. Видалити разом із посиланнями?",
                        "Попередження",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Warning);
                    if (forceConfirm == DialogResult.Yes)
                    {
                        _termManager.DeleteTerm(termToDelete.Id, force: true);
                        _isDirty = true;
                        RefreshDisplay();
                    }
                }
                else
                {
                    MessageBox.Show(ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dGVTerms.CurrentRow == null)
            {
                MessageBox.Show("Оберіть термін для редагування.");
                return;
            }

            List<string> categories = new List<string>();
            for (int i = 1; i < cmbCategorySearch.Items.Count; i++)
            {
                categories.Add(cmbCategorySearch.Items[i].ToString());
            }

            string termName = dGVTerms.CurrentRow.Cells["colName"].Value.ToString();
            Term termToEdit = null;
            foreach (var t in _termManager.Terms)
            {
                if (t.Name == termName)
                {
                    termToEdit = t;
                    break;
                }
            }

            if (termToEdit == null)
            {
                MessageBox.Show("Термін не знайдено.");
                return;
            }

            AddEditTermForm editForm = new AddEditTermForm(categories, 2, termToEdit);
            if (editForm.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    _termManager.UpdateTerm(editForm.CreatedTerm, 1);
                    _isDirty = true;
                    RefreshDisplay();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void butReview_Click(object sender, EventArgs e)
        {
            if (dGVTerms.CurrentRow == null)
            {
                MessageBox.Show("Оберіть термін для перегляду.");
                return;
            }

            List<string> categories = new List<string>();
            for (int i = 1; i < cmbCategorySearch.Items.Count; i++)
            {
                categories.Add(cmbCategorySearch.Items[i].ToString());
            }

            string termName = dGVTerms.CurrentRow.Cells["colName"].Value.ToString();
            Term termToView = null;
            foreach (var t in _termManager.Terms)
            {
                if (t.Name == termName)
                {
                    termToView = t;
                    break;
                }
            }

            if (termToView == null)
            {
                MessageBox.Show("Термін не знайдено.");
                return;
            }

            AddEditTermForm viewForm = new AddEditTermForm(categories, 3, termToView);
            viewForm.ShowDialog();
        }

        private void AddTSMI_Click(object sender, EventArgs e)
        {
            butAdd.PerformClick();
        }

        private void EditTSMI_Click(object sender, EventArgs e)
        {
            btnEdit.PerformClick();
        }

        private void DeleteTSMI_Click(object sender, EventArgs e)
        {
            btnDelete.PerformClick();
        }

        private void dGVTerms_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            butReview.PerformClick();
        }

        private void btnLinks_Click(object sender, EventArgs e)
        {
            if (dGVTerms.CurrentRow == null)
            {
                MessageBox.Show("Оберіть термін для зміни зв'язків.");
                return;
            }

            string termName = dGVTerms.CurrentRow.Cells["colName"].Value.ToString();
            Term termToView = null;
            List<Term> termsToLink = new List<Term>();

            foreach (var t in _termManager.Terms)
            {
                if (t.Name == termName)
                    termToView = t;
                else
                    termsToLink.Add(t);
            }

            if (termToView == null)
            {
                MessageBox.Show("Термін не знайдено.");
                return;
            }

            List<Term> termLinks = new List<Term>();
            foreach (var linkId in termToView.LinkedTermIds)
            {
                for (int j = 0; j < termsToLink.Count; j++)
                {
                    if (termsToLink[j].Id == linkId)
                    {
                        termLinks.Add(termsToLink[j]);
                        termsToLink.RemoveAt(j);
                        break;
                    }
                }
            }

            LinksForm linksForm = new LinksForm(termToView, termsToLink, termLinks);
            if (linksForm.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    _termManager.UpdateTerm(linksForm.CreatedTerm, 2);
                    _isDirty = true;
                    RefreshDisplay();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ConnectionsTSMI_Click(object sender, EventArgs e)
        {
            btnLinks.PerformClick();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            List<Term> foundTerms = _termManager.FindTerms(
                txtNameSearch.Text,
                cmbCategorySearch.SelectedItem?.ToString() ?? "",
                cmbStatusSearch.SelectedItem?.ToString() ?? "",
                txtDefinitionSearch.Text);

            dGVTerms.Rows.Clear();
            foreach (var t in foundTerms)
                dGVTerms.Rows.Add(t.Name, t.Category, t.Status);
        }

        private void btnChain_Click(object sender, EventArgs e)
        {
            if (dGVTerms.CurrentRow == null)
            {
                MessageBox.Show("Оберіть термін для перегляду ланцюжка.");
                return;
            }

            string termName = dGVTerms.CurrentRow.Cells["colName"].Value.ToString();
            Term selectedTerm = null;
            foreach (var t in _termManager.Terms)
            {
                if (t.Name == termName)
                {
                    selectedTerm = t;
                    break;
                }
            }

            if (selectedTerm == null)
            {
                MessageBox.Show("Термін не знайдено.");
                return;
            }

            LinksTree chainForm = new LinksTree(selectedTerm, _termManager.Terms);
            chainForm.ShowDialog();
        }

        private void DefinitionChainTSMI_Click(object sender, EventArgs e)
        {
            btnChain.PerformClick();
        }

        private void OpenTSMI_Click(object sender, EventArgs e)
        {
            if (_isDirty)
            {
                if (MessageBox.Show("Втратити зміни?", "Увага", MessageBoxButtons.YesNo) != DialogResult.Yes)
                    return;
            }
            OpenFile();
        }

        private void SaveTSMI_Click(object sender, EventArgs e)
        {
            SaveCurrent();
        }

        private void SaveAsTSMI_Click(object sender, EventArgs e)
        {
            SaveAs();
        }
    }
}