﻿namespace TerminologyApp
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            FileTSMI = new ToolStripMenuItem();
            OpenTSMI = new ToolStripMenuItem();
            SaveTSMI = new ToolStripMenuItem();
            SaveAsTSMI = new ToolStripMenuItem();
            toolStripSeparatorFile = new ToolStripSeparator();
            ExitTSMI = new ToolStripMenuItem();
            EditingTSMI = new ToolStripMenuItem();
            AddTSMI = new ToolStripMenuItem();
            EditTSMI = new ToolStripMenuItem();
            DeleteTSMI = new ToolStripMenuItem();
            toolStripSeparatorEdit = new ToolStripSeparator();
            ConnectionsTSMI = new ToolStripMenuItem();
            DefinitionChainTSMI = new ToolStripMenuItem();
            ReferenceTSMI = new ToolStripMenuItem();
            AboutTSMI = new ToolStripMenuItem();
            gBSearch = new GroupBox();
            btnReset = new Button();
            btnSearch = new Button();
            cmbStatusSearch = new ComboBox();
            label5 = new Label();
            cmbCategorySearch = new ComboBox();
            label4 = new Label();
            txtDefinitionSearch = new TextBox();
            label3 = new Label();
            txtNameSearch = new TextBox();
            label2 = new Label();
            gBList = new GroupBox();
            dGVTerms = new DataGridView();
            colName = new DataGridViewTextBoxColumn();
            colCategory = new DataGridViewTextBoxColumn();
            colStatus = new DataGridViewTextBoxColumn();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            butAdd = new Button();
            btnDelete = new Button();
            btnEdit = new Button();
            butReview = new Button();
            btnLinks = new Button();
            btnChain = new Button();
            menuStrip1.SuspendLayout();
            gBSearch.SuspendLayout();
            gBList.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dGVTerms).BeginInit();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = Color.White;
            menuStrip1.Items.AddRange(new ToolStripItem[] { FileTSMI, EditingTSMI, ReferenceTSMI });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // FileTSMI
            // 
            FileTSMI.DropDownItems.AddRange(new ToolStripItem[] { OpenTSMI, SaveTSMI, SaveAsTSMI, toolStripSeparatorFile, ExitTSMI });
            FileTSMI.Name = "FileTSMI";
            FileTSMI.Size = new Size(48, 20);
            FileTSMI.Text = "Файл";
            // 
            // OpenTSMI
            // 
            OpenTSMI.Name = "OpenTSMI";
            OpenTSMI.ShortcutKeys = Keys.Control | Keys.O;
            OpenTSMI.Size = new Size(184, 22);
            OpenTSMI.Text = "Відкрити...";
            OpenTSMI.Click += OpenTSMI_Click;
            // 
            // SaveTSMI
            // 
            SaveTSMI.Name = "SaveTSMI";
            SaveTSMI.ShortcutKeys = Keys.Control | Keys.S;
            SaveTSMI.Size = new Size(184, 22);
            SaveTSMI.Text = "Зберегти";
            SaveTSMI.Click += SaveTSMI_Click;
            // 
            // SaveAsTSMI
            // 
            SaveAsTSMI.Name = "SaveAsTSMI";
            SaveAsTSMI.ShortcutKeys = Keys.Alt | Keys.S;
            SaveAsTSMI.Size = new Size(184, 22);
            SaveAsTSMI.Text = "Зберегти як...";
            SaveAsTSMI.Click += SaveAsTSMI_Click;
            // 
            // toolStripSeparatorFile
            // 
            toolStripSeparatorFile.Name = "toolStripSeparatorFile";
            toolStripSeparatorFile.Size = new Size(181, 6);
            // 
            // ExitTSMI
            // 
            ExitTSMI.Name = "ExitTSMI";
            ExitTSMI.ShortcutKeys = Keys.Control | Keys.E;
            ExitTSMI.Size = new Size(184, 22);
            ExitTSMI.Text = "Вихід";
            ExitTSMI.Click += ExitTSMI_Click;
            // 
            // EditingTSMI
            // 
            EditingTSMI.DropDownItems.AddRange(new ToolStripItem[] { AddTSMI, EditTSMI, DeleteTSMI, toolStripSeparatorEdit, ConnectionsTSMI, DefinitionChainTSMI });
            EditingTSMI.Name = "EditingTSMI";
            EditingTSMI.Size = new Size(59, 20);
            EditingTSMI.Text = "Правка";
            // 
            // AddTSMI
            // 
            AddTSMI.Name = "AddTSMI";
            AddTSMI.ShortcutKeys = Keys.Alt | Keys.A;
            AddTSMI.Size = new Size(232, 22);
            AddTSMI.Text = "Додати";
            AddTSMI.Click += AddTSMI_Click;
            // 
            // EditTSMI
            // 
            EditTSMI.Name = "EditTSMI";
            EditTSMI.ShortcutKeys = Keys.Alt | Keys.E;
            EditTSMI.Size = new Size(232, 22);
            EditTSMI.Text = "Редагувати";
            EditTSMI.Click += EditTSMI_Click;
            // 
            // DeleteTSMI
            // 
            DeleteTSMI.Name = "DeleteTSMI";
            DeleteTSMI.ShortcutKeys = Keys.Alt | Keys.D;
            DeleteTSMI.Size = new Size(232, 22);
            DeleteTSMI.Text = "Видалити";
            DeleteTSMI.Click += DeleteTSMI_Click;
            // 
            // toolStripSeparatorEdit
            // 
            toolStripSeparatorEdit.Name = "toolStripSeparatorEdit";
            toolStripSeparatorEdit.Size = new Size(229, 6);
            // 
            // ConnectionsTSMI
            // 
            ConnectionsTSMI.Name = "ConnectionsTSMI";
            ConnectionsTSMI.ShortcutKeys = Keys.Alt | Keys.L;
            ConnectionsTSMI.Size = new Size(232, 22);
            ConnectionsTSMI.Text = "Зв'язки";
            ConnectionsTSMI.Click += ConnectionsTSMI_Click;
            // 
            // DefinitionChainTSMI
            // 
            DefinitionChainTSMI.Name = "DefinitionChainTSMI";
            DefinitionChainTSMI.ShortcutKeys = Keys.Alt | Keys.C;
            DefinitionChainTSMI.Size = new Size(232, 22);
            DefinitionChainTSMI.Text = "Ланцюжок визначень";
            DefinitionChainTSMI.Click += DefinitionChainTSMI_Click;
            // 
            // ReferenceTSMI
            // 
            ReferenceTSMI.DropDownItems.AddRange(new ToolStripItem[] { AboutTSMI });
            ReferenceTSMI.Name = "ReferenceTSMI";
            ReferenceTSMI.Size = new Size(61, 20);
            ReferenceTSMI.Text = "Довідка";
            // 
            // AboutTSMI
            // 
            AboutTSMI.Name = "AboutTSMI";
            AboutTSMI.ShortcutKeys = Keys.Control | Keys.I;
            AboutTSMI.Size = new Size(191, 22);
            AboutTSMI.Text = "Про програму";
            AboutTSMI.Click += AboutTSMI_Click;
            // 
            // gBSearch
            // 
            gBSearch.Controls.Add(btnReset);
            gBSearch.Controls.Add(btnSearch);
            gBSearch.Controls.Add(cmbStatusSearch);
            gBSearch.Controls.Add(label5);
            gBSearch.Controls.Add(cmbCategorySearch);
            gBSearch.Controls.Add(label4);
            gBSearch.Controls.Add(txtDefinitionSearch);
            gBSearch.Controls.Add(label3);
            gBSearch.Controls.Add(txtNameSearch);
            gBSearch.Controls.Add(label2);
            gBSearch.Location = new Point(12, 27);
            gBSearch.Name = "gBSearch";
            gBSearch.Size = new Size(776, 98);
            gBSearch.TabIndex = 1;
            gBSearch.TabStop = false;
            gBSearch.Text = "Пошук";
            // 
            // btnReset
            // 
            btnReset.Location = new Point(595, 60);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(75, 23);
            btnReset.TabIndex = 10;
            btnReset.Text = "Скинути";
            btnReset.UseVisualStyleBackColor = true;
            btnReset.Click += btnReset_Click;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(595, 18);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(75, 23);
            btnSearch.TabIndex = 9;
            btnSearch.Text = "Пошук";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // cmbStatusSearch
            // 
            cmbStatusSearch.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbStatusSearch.FormattingEnabled = true;
            cmbStatusSearch.Items.AddRange(new object[] { "", "проєктний", "затверджений", "застарілий" });
            cmbStatusSearch.Location = new Point(382, 60);
            cmbStatusSearch.Name = "cmbStatusSearch";
            cmbStatusSearch.Size = new Size(121, 23);
            cmbStatusSearch.TabIndex = 8;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(330, 63);
            label5.Name = "label5";
            label5.Size = new Size(46, 15);
            label5.TabIndex = 7;
            label5.Text = "Статус:";
            // 
            // cmbCategorySearch
            // 
            cmbCategorySearch.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbCategorySearch.FormattingEnabled = true;
            cmbCategorySearch.Items.AddRange(new object[] { "" });
            cmbCategorySearch.Location = new Point(382, 18);
            cmbCategorySearch.Name = "cmbCategorySearch";
            cmbCategorySearch.Size = new Size(121, 23);
            cmbCategorySearch.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(314, 21);
            label4.Name = "label4";
            label4.Size = new Size(62, 15);
            label4.TabIndex = 5;
            label4.Text = "Категорія:";
            // 
            // txtDefinitionSearch
            // 
            txtDefinitionSearch.Location = new Point(91, 60);
            txtDefinitionSearch.Name = "txtDefinitionSearch";
            txtDefinitionSearch.Size = new Size(220, 23);
            txtDefinitionSearch.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(10, 63);
            label3.Name = "label3";
            label3.Size = new Size(75, 15);
            label3.TabIndex = 3;
            label3.Text = "Визначення:";
            // 
            // txtNameSearch
            // 
            txtNameSearch.Location = new Point(58, 18);
            txtNameSearch.Name = "txtNameSearch";
            txtNameSearch.Size = new Size(220, 23);
            txtNameSearch.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(10, 21);
            label2.Name = "label2";
            label2.Size = new Size(42, 15);
            label2.TabIndex = 1;
            label2.Text = "Назва:";
            // 
            // gBList
            // 
            gBList.Controls.Add(dGVTerms);
            gBList.Location = new Point(12, 131);
            gBList.Name = "gBList";
            gBList.Size = new Size(776, 194);
            gBList.TabIndex = 11;
            gBList.TabStop = false;
            gBList.Text = "Список термінів";
            // 
            // dGVTerms
            // 
            dGVTerms.AllowUserToAddRows = false;
            dGVTerms.AllowUserToDeleteRows = false;
            dGVTerms.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dGVTerms.BackgroundColor = Color.White;
            dGVTerms.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dGVTerms.Columns.AddRange(new DataGridViewColumn[] { colName, colCategory, colStatus });
            dGVTerms.Dock = DockStyle.Fill;
            dGVTerms.Location = new Point(3, 19);
            dGVTerms.MultiSelect = false;
            dGVTerms.Name = "dGVTerms";
            dGVTerms.ReadOnly = true;
            dGVTerms.RowHeadersVisible = false;
            dGVTerms.RowTemplate.ReadOnly = true;
            dGVTerms.RowTemplate.Resizable = DataGridViewTriState.False;
            dGVTerms.ScrollBars = ScrollBars.Vertical;
            dGVTerms.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dGVTerms.ShowCellToolTips = false;
            dGVTerms.Size = new Size(770, 172);
            dGVTerms.TabIndex = 0;
            dGVTerms.CellDoubleClick += dGVTerms_CellDoubleClick;
            // 
            // colName
            // 
            colName.FillWeight = 55F;
            colName.HeaderText = "Назва терміна";
            colName.Name = "colName";
            colName.ReadOnly = true;
            colName.Resizable = DataGridViewTriState.False;
            colName.SortMode = DataGridViewColumnSortMode.NotSortable;
            // 
            // colCategory
            // 
            colCategory.FillWeight = 25F;
            colCategory.HeaderText = "Категорія";
            colCategory.Name = "colCategory";
            colCategory.ReadOnly = true;
            colCategory.Resizable = DataGridViewTriState.False;
            colCategory.SortMode = DataGridViewColumnSortMode.NotSortable;
            // 
            // colStatus
            // 
            colStatus.FillWeight = 20F;
            colStatus.HeaderText = "Статус";
            colStatus.Name = "colStatus";
            colStatus.ReadOnly = true;
            colStatus.Resizable = DataGridViewTriState.False;
            colStatus.SortMode = DataGridViewColumnSortMode.NotSortable;
            // 
            // butAdd
            // 
            butAdd.Location = new Point(115, 347);
            butAdd.Name = "butAdd";
            butAdd.Size = new Size(75, 23);
            butAdd.TabIndex = 12;
            butAdd.Text = "Додати";
            butAdd.UseVisualStyleBackColor = true;
            butAdd.Click += butAdd_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(286, 347);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(75, 23);
            btnDelete.TabIndex = 13;
            btnDelete.Text = "Видалити";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(196, 347);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(84, 23);
            btnEdit.TabIndex = 14;
            btnEdit.Text = "Редагувати";
            btnEdit.UseVisualStyleBackColor = true;
            btnEdit.Click += btnEdit_Click;
            // 
            // butReview
            // 
            butReview.Location = new Point(15, 347);
            butReview.Name = "butReview";
            butReview.Size = new Size(94, 23);
            butReview.TabIndex = 15;
            butReview.Text = "Переглянути";
            butReview.UseVisualStyleBackColor = true;
            butReview.Click += butReview_Click;
            // 
            // btnLinks
            // 
            btnLinks.Location = new Point(367, 347);
            btnLinks.Name = "btnLinks";
            btnLinks.Size = new Size(75, 23);
            btnLinks.TabIndex = 16;
            btnLinks.Text = "Зв'язки";
            btnLinks.UseVisualStyleBackColor = true;
            btnLinks.Click += btnLinks_Click;
            // 
            // btnChain
            // 
            btnChain.Location = new Point(448, 347);
            btnChain.Name = "btnChain";
            btnChain.Size = new Size(75, 23);
            btnChain.TabIndex = 17;
            btnChain.Text = "Ланцюжок";
            btnChain.UseVisualStyleBackColor = true;
            btnChain.Click += btnChain_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 403);
            Controls.Add(btnChain);
            Controls.Add(btnLinks);
            Controls.Add(butReview);
            Controls.Add(btnEdit);
            Controls.Add(btnDelete);
            Controls.Add(butAdd);
            Controls.Add(gBList);
            Controls.Add(gBSearch);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "MainForm";
            Text = "MainForm";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            gBSearch.ResumeLayout(false);
            gBSearch.PerformLayout();
            gBList.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dGVTerms).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem FileTSMI;
        private ToolStripMenuItem OpenTSMI;
        private ToolStripMenuItem SaveTSMI;
        private ToolStripMenuItem SaveAsTSMI;
        private ToolStripSeparator toolStripSeparatorFile;
        private ToolStripMenuItem ExitTSMI;
        private ToolStripMenuItem EditingTSMI;
        private ToolStripMenuItem AddTSMI;
        private ToolStripMenuItem EditTSMI;
        private ToolStripMenuItem DeleteTSMI;
        private ToolStripSeparator toolStripSeparatorEdit;
        private ToolStripMenuItem ConnectionsTSMI;
        private ToolStripMenuItem ReferenceTSMI;
        private ToolStripMenuItem DefinitionChainTSMI;
        private ToolStripMenuItem AboutTSMI;
        private GroupBox gBSearch;
        private Label label5;
        private ComboBox cmbCategorySearch;
        private Label label4;
        private TextBox txtDefinitionSearch;
        private Label label3;
        private TextBox txtNameSearch;
        private Label label2;
        private ComboBox cmbStatusSearch;
        private Button btnReset;
        private Button btnSearch;
        private GroupBox gBList;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Button butAdd;
        private DataGridView dGVTerms;
        private DataGridViewTextBoxColumn colName;
        private DataGridViewTextBoxColumn colCategory;
        private DataGridViewTextBoxColumn colStatus;
        private Button btnDelete;
        private Button btnEdit;
        private Button butReview;
        private Button btnLinks;
        private Button btnChain;
    }
}