using System;
using System.Collections.Generic;

namespace TerminologyApp.Models
{
    public class Term
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Definition { get; set; }
        public string Category { get; set; }
        public string Status { get; set; }
        public string ImagePath { get; set; }
        public List<Guid> LinkedTermIds { get; set; }

        public Term()
        {
            Id = Guid.NewGuid();
            Name = string.Empty;
            Definition = string.Empty;
            Category = "Загальна";
            Status = "проєктний";
            ImagePath = string.Empty;
            LinkedTermIds = new List<Guid>();
        }

        public Term(string name, string definition, string category, string status, string imagePath)
        {
            Id = Guid.NewGuid();
            Name = name;
            Definition = definition;
            Category = category;
            Status = status;
            ImagePath = imagePath;
            LinkedTermIds = new List<Guid>();
        }
    }
}