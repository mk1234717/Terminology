﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using TerminologyApp.Models;

namespace TerminologyApp.Services
{
    public class DataStorageService
    {
        public void SaveToFile(List<Term> terms, string filePath)
        {
            string json = JsonSerializer.Serialize(terms, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(filePath, json);
        }

        public List<Term> LoadFromFile(string filePath)
        {
            if (!File.Exists(filePath))
                return new List<Term>();

            string json = File.ReadAllText(filePath);
            return JsonSerializer.Deserialize<List<Term>>(json) ?? new List<Term>();
        }
    }
}