﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TerminologyApp
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void ExitTSMI_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AboutTSMI_Click(object sender, EventArgs e)
        {
            string message =
        "Термінологія\n" +
        "Версія 1.0\n\n" +
        "Програма призначена для створення та ведення бази визначень термінів певної науки або предметної області.\n\n" +
        "Основні можливості:\n" +
        "• Додавання, редагування, видалення термінів\n" +
        "• Встановлення зв'язків між поняттями\n" +
        "• Перегляд ланцюжка визначень до первинних понять\n" +
        "• Пошук за назвою, категорією, статусом, текстом визначення\n" +
        "• Збереження та завантаження бази у JSON";

            MessageBox.Show(message, "Про програму", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtNameSearch.Clear();
            txtDefinitionSearch.Clear();
            cmbCategorySearch.SelectedIndex = -1;
            cmbStatusSearch.SelectedIndex = -1;
        }
    }
}
