using System;
using System.Collections.Generic;

namespace TerminologyApp.Models
{
    public class TermManager
    {
        public List<Term> Terms { get; private set; }

        public TermManager()
        {
            Terms = new List<Term>();
        }

        public void AddTerm(Term term)
        {
            for (int i = 0; i < Terms.Count; i++)
            {
                if (Terms[i].Name.Equals(term.Name, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException($"Термін з назвою \"{term.Name}\" вже існує");
            }

            Terms.Add(term);
        }

        public Term GetTermById(Guid id)
        {
            for (int i = 0; i < Terms.Count; i++)
            {
                if (Terms[i].Id == id)
                    return Terms[i];
            }
            return null;
        }

        public void UpdateTerm(Term updatedTerm, int form)
        {
            Term existingTerm = GetTermById(updatedTerm.Id);
            if (existingTerm == null)
                throw new InvalidOperationException($"Термін з Id {updatedTerm.Id} не знайдено");

            for (int i = 0; i < Terms.Count; i++)
            {
                if (Terms[i].Id != updatedTerm.Id && Terms[i].Name.Equals(updatedTerm.Name, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException($"Термін з назвою \"{updatedTerm.Name}\" вже існує");
            }

            if (form == 1)
            {
                existingTerm.Name = updatedTerm.Name;
                existingTerm.Definition = updatedTerm.Definition;
                existingTerm.Category = updatedTerm.Category;
                existingTerm.Status = updatedTerm.Status;
                existingTerm.ImagePath = updatedTerm.ImagePath;
            }
            
            if (form == 2)
            {
                existingTerm.LinkedTermIds = updatedTerm.LinkedTermIds;
            }
        }

        public void DeleteTerm(Guid id, bool force = false)
        {
            Term termToDelete = GetTermById(id);
            if (termToDelete == null)
                throw new InvalidOperationException($"Термін з Id {id} не знайдено");

            List<Guid> referencingTerms = new List<Guid>();
            for (int i = 0; i < Terms.Count; i++)
            {
                Term t = Terms[i];
                for (int j = 0; j < t.LinkedTermIds.Count; j++)
                {
                    if (t.LinkedTermIds[j] == id)
                    {
                        referencingTerms.Add(t.Id);
                        break;
                    }
                }
            }

            if (referencingTerms.Count > 0)
            {
                if (!force)
                    throw new InvalidOperationException("На цей термін посилаються інші терміни. Використайте force=true для примусового видалення.");

                for (int i = 0; i < Terms.Count; i++)
                {
                    Term t = Terms[i];
                    List<Guid> newLinks = new List<Guid>();
                    for (int j = 0; j < t.LinkedTermIds.Count; j++)
                    {
                        if (t.LinkedTermIds[j] == id)
                        {
                            t.LinkedTermIds.RemoveAt(j);
                            break;
                        }
                    }
                    t.LinkedTermIds = newLinks;
                }
            }

            for (int i = 0; i < Terms.Count; i++)
            {
                if (Terms[i].Id == id)
                {
                    Terms.RemoveAt(i);
                    break;
                }
            }
        }

        public List<Term> FindTerms(string name, string category, string status, string definitionText)
        {
            List<Term> results = new List<Term>();

            for (int i = 0; i < Terms.Count; i++)
            {
                Term term = Terms[i];
                bool match = true;

                if (!string.IsNullOrWhiteSpace(name))
                {
                    if (!term.Name.Contains(name, StringComparison.OrdinalIgnoreCase))
                        match = false;
                }

                if (match && !string.IsNullOrWhiteSpace(category) && category != "")
                {
                    if (!term.Category.Equals(category, StringComparison.OrdinalIgnoreCase))
                        match = false;
                }

                if (match && !string.IsNullOrWhiteSpace(status) && status != "")
                {
                    if (!term.Status.Equals(status, StringComparison.OrdinalIgnoreCase))
                        match = false;
                }

                if (match && !string.IsNullOrWhiteSpace(definitionText))
                {
                    if (!term.Definition.Contains(definitionText, StringComparison.OrdinalIgnoreCase))
                        match = false;
                }

                if (match)
                    results.Add(term);
            }

            return results;
        }
    }
}